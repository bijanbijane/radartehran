import assert from 'node:assert/strict';
import {
  normalizePersianText,
  hasAffirmativeMatch,
  resolveAmenityStatus,
  resolveBuildingAge,
  extractListingSpecsFromText,
  parseIranianPriceToMillionToman,
  computeQualityMultiplier,
  aggregateNeighborhoodMarketMetrics,
  applySpatialGrowthFallback,
  verifyPricingEngineIntegrity,
} from '../src/data/realMarketPriceAggregator';

console.log('🧪 Running Iran-Native Hedonic Real Market Price Aggregator Test Suite (v6.2)...\n');

// 1. Persian NLP Normalization & Word-Number Context Guard
const t1 = normalizePersianText('قیمت ۱۲.۵۰۰.۰۰۰.۰۰۰ تومان در طبقه ۲/۵ با متراژ ۸۵ متر');
assert.ok(t1.includes('12500000000'), 'Multi-thousands separators stripped safely');
assert.ok(t1.includes('طبقه 2/5'), 'Fractional floor notation preserved without slash corruption');

const t2 = normalizePersianText('ساخت ۱۳۸۵ در تاریخ 1403/05/12 با قیمت ۱۲٫۵ میلیارد');
assert.ok(t2.includes('12.5 میلیارد'), 'Persian decimal separator converted to dot');

const t3 = normalizePersianText('واحد صفر تا صد بازسازی شده با قیمت یازده میلیارد و پانصد');
assert.ok(t3.includes('صفر تا صد'), 'Idiom صفر تا صد preserved');
assert.ok(t3.includes('11500 میلیون'), 'Compound word-number price folded to 11500 میلیون');

// 2. Sub-clause Isolated Negation & Strict و-Conjoined Pre-Negation
assert.equal(hasAffirmativeMatch('دارای پارکینگ و انباری سندی', 'پارکینگ'), true, 'Affirmative parking match');
assert.equal(hasAffirmativeMatch('واحد فاقد پارکینگ سندی می‌باشد', 'پارکینگ'), false, 'Pre-negation detected');
assert.equal(hasAffirmativeMatch('پارکینگ اختصاصی ندارد', 'پارکینگ'), false, 'Post-negation detected');
assert.equal(hasAffirmativeMatch('بدون آسانسور اما دارای پارکینگ سندی', 'پارکینگ'), true, 'Sub-clause isolation preserves positive switch');
assert.equal(hasAffirmativeMatch('بدون آسانسور اما دارای پارکینگ سندی', 'آسانسور'), false, 'Sub-clause isolation detects negative clause');
assert.equal(hasAffirmativeMatch('بدون پارکینگ و انباری', 'انباری'), false, 'Conjoined و pre-negation negates second noun');
assert.equal(hasAffirmativeMatch('بدون پارکینگ آسانسور دارد', 'آسانسور'), true, 'Unconjoined second noun with دارد is affirmative');

// 3. Amenity Status Resolution
assert.equal(resolveAmenityStatus('واحد بسیار نورگیر و تمیز', /پارکینگ/, true), true, 'Default value respected when absent');
assert.equal(resolveAmenityStatus('بدون پارکینگ', /پارکینگ/, true), false, 'Affirmative check overrides default');

// 4. Building Age Resolution & Fake Brand-New Guard
assert.equal(resolveBuildingAge(null, 'قبل از 1370'), 36, 'Pre-1370 mapped to 36');
assert.equal(resolveBuildingAge(null, 'متراژ سال ساخت اتاق\n95 1395 2'), 10, 'Divar header table parsed');
assert.equal(resolveBuildingAge(null, 'واحد نوساز کلید نخورده'), 0, 'Brand-new key-unturned is age 0');
assert.equal(resolveBuildingAge(1398, 'نوساز کلید نخورده'), 7, 'Direct numeric solar year takes priority over stale text');
assert.equal(resolveBuildingAge(null, 'نوساز بازسازی شده کامل'), 8, 'Fake brand-new guard sets age to 8');

// 5. Windowed Spec Extractor & Nullish-Safe Floor
const specs = extractListingSpecsFromText('زمین ۲۰۰ متری، بنای مفید ۹۰ متری طبقه ۳ از ۶ فول امکانات با پارکینگ و آسانسور');
assert.equal(specs.sqm, 90, 'Apartment area extracted ignoring land area');
assert.equal(specs.floor, 3, 'Floor extracted');
assert.equal(specs.totalFloors, 6, 'Total floors extracted');
assert.equal(specs.hasParking, true, 'Parking confirmed');
assert.equal(specs.hasElevator, true, 'Elevator confirmed');

const groundSpecs = extractListingSpecsFromText('آپارتمان ۸۰ متر طبقه همکف');
assert.equal(groundSpecs.floor, 0, 'Ground floor (همکف) preserved as 0');

// 6. Iranian Price Parsing
const netCashPrice = parseIranianPriceToMillionToman('نقدینگی ۱.۵ میلیارد + وام ۸۰۰ میلیون + رهن مستاجر ۴۰۰ میلیون');
assert.equal(netCashPrice.totalMillion, 2700, 'Net-cash composite price summed accurately without double-counting');

const bnPrice = parseIranianPriceToMillionToman('قیمت کل ۱۲ میلیارد و ۵۰۰ میلیون تومان');
assert.equal(bnPrice.totalMillion, 12500, 'Billion and million parsed together');

// 7. Quality Multiplier
const mult5yr = computeQualityMultiplier({ age: 5, floor: 2, hasParking: true, hasElevator: true, hasStorage: true });
assert.ok(Math.abs(mult5yr - 1.0) <= 0.03, `5-year standard unit multiplier centered near 1.0 (got ${mult5yr})`);

const multNew = computeQualityMultiplier({ age: 0, renovationStatus: 'luxury_renovated', floor: 4 });
assert.ok(multNew > 1.05, `Brand-new luxury unit has premium (got ${multNew})`);

const multOld = computeQualityMultiplier({ age: 35, floor: 4, hasElevator: false, hasParking: false });
assert.ok(multOld >= 0.68 && multOld <= 0.85, `Old unit without elevator/parking clamped safely (got ${multOld})`);

// 8. Market Aggregator with EMA velocity cap, Provenance Taxonomy & Semantic Integrity (WS-ARGON5-A)
const aggCold = aggregateNeighborhoodMarketMetrics(1, 'سعادت‌آباد', 150, []);
assert.equal(aggCold.isBootstrapped, true, 'Zero samples yields bootstrapped cold-start');
assert.equal(aggCold.observedSampleCount, 0, 'Zero observed samples never inflated by synthetic rows');
assert.equal(aggCold.eligibleObservedCount, 0, 'Zero eligible observed samples when input is empty');
assert.equal(aggCold.syntheticSampleCount, 12, 'Synthetic sample count explicitly tracked as 12');
assert.equal(aggCold.provenance, 'REFERENCE_BASELINE', 'Zero samples marked as REFERENCE_BASELINE');
assert.equal(aggCold.epistemicStatus, 'SYNTHETIC', 'Cold-start epistemic status is SYNTHETIC');
assert.equal(aggCold.dataMode, 'ILLUSTRATIVE_BOOTSTRAP', 'Cold-start dataMode is ILLUSTRATIVE_BOOTSTRAP');
assert.equal(aggCold.calibratedConfidencePct, null, 'Bootstrap result never exposes arbitrary numeric percentage as calibrated statistical confidence');
assert.equal(aggCold.observedMeanPerSqm, null, 'Synthetic rows never enter observedMeanPerSqm (null when missing, not 0)');
assert.equal(aggCold.observedMedianPerSqm, null, 'Synthetic rows never enter observedMedianPerSqm (null when missing, not 0)');
assert.equal(aggCold.observedIqrLowPerSqm, null, 'Synthetic rows never enter observedIqrLowPerSqm');
assert.equal(aggCold.observedIqrHighPerSqm, null, 'Synthetic rows never enter observedIqrHighPerSqm');
assert.equal(aggCold.fraudReviewState, 'NONE', 'Zero samples has NONE fraudReviewState');
assert.equal(aggCold.dealPriceProvenance, 'HEURISTIC_ESTIMATE', 'Deal price explicitly marked as HEURISTIC_ESTIMATE');
assert.equal(aggCold.evidenceQuality, 'INSUFFICIENT_OBSERVATIONS', 'Zero samples marked as INSUFFICIENT_OBSERVATIONS');
assert.equal(aggCold.evidenceIndexScore, 0, 'Zero observed samples yields 0 evidence index score');
assert.notEqual(aggCold.marketRegime, 'FROZEN', 'Cold-start never defaults to FROZEN');
assert.ok(aggCold.autoBargainIds.length >= 2, 'Cold-start bootstrap preserves pre-IQR bargains');

// 1 and 2 observed samples (LIMITED_OBSERVATIONS, blended with reference baseline, not discarded)
const aggOne = aggregateNeighborhoodMarketMetrics(1, 'سعادت‌آباد', 150, [
  { id: 'obs-1', askingTotalMillion: 12800, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ و آسانسور', yearOrAge: 1400 },
]);
assert.equal(aggOne.observedSampleCount, 1, '1 observed sample reported accurately');
assert.equal(aggOne.eligibleObservedCount, 1, '1 eligible observed sample preserved');
assert.equal(aggOne.provenance, 'HEURISTIC_ESTIMATE', '1 sample marked as HEURISTIC_ESTIMATE');
assert.equal(aggOne.epistemicStatus, 'ESTIMATED', '1 sample epistemicStatus is ESTIMATED');
assert.equal(aggOne.dataMode, 'LIMITED_OBSERVED_BLEND', '1 sample dataMode is LIMITED_OBSERVED_BLEND');
assert.ok(aggOne.observedMeanPerSqm !== null && aggOne.observedMeanPerSqm > 100, '1 observed sample populates observedMeanPerSqm without synthetic contamination');
assert.equal(aggOne.observedIqrLowPerSqm, null, '< 3 observed samples keeps observedIqrLowPerSqm null');
assert.equal(aggOne.evidenceQuality, 'LIMITED_OBSERVATIONS', '1 sample marked as LIMITED_OBSERVATIONS');
assert.equal(aggOne.evidenceIndexScore, 35, '1 sample yields 35 evidence index score');
assert.ok(aggOne.autoBargainIds.includes('obs-1'), 'Real observed bargain in 1-sample input is preserved in autoBargainIds');

const aggTwo = aggregateNeighborhoodMarketMetrics(1, 'سعادت‌آباد', 150, [
  { id: 'obs-1', askingTotalMillion: 13500, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { id: 'obs-2', askingTotalMillion: 14000, description: '۱۰۰ متر طبقه ۳ ساخت ۱۴۰۱ با پارکینگ', yearOrAge: 1401 },
]);
assert.equal(aggTwo.observedSampleCount, 2, '2 observed samples reported accurately');
assert.equal(aggTwo.eligibleObservedCount, 2, '2 eligible observed samples preserved');
assert.equal(aggTwo.evidenceQuality, 'LIMITED_OBSERVATIONS', '2 samples marked as LIMITED_OBSERVATIONS');
assert.equal(aggTwo.evidenceIndexScore, 52, '2 samples yields 52 evidence index score');

const samples = [
  { askingTotalMillion: 14000, description: '۱۰۰ متر طبقه ۳ با پارکینگ ساخت ۱۴۰۰', yearOrAge: 1400 },
  { askingTotalMillion: 14500, description: '۱۰۰ متر طبقه ۲ ساخت ۱۳۹۸ با آسانسور', yearOrAge: 1398 },
  { askingTotalMillion: 13800, description: '۱۰۰ متر طبقه ۴ با پارکینگ ساخت ۱۴۰۱', yearOrAge: 1401 },
  { askingTotalMillion: 14200, description: '۱۰۰ متر طبقه ۲ ساخت ۱۳۹۹', yearOrAge: 1399 },
];
const aggWarm = aggregateNeighborhoodMarketMetrics(1, 'سعادت‌آباد', 140, samples, 140);
assert.equal(aggWarm.isBootstrapped, false, 'Sufficient samples is not bootstrapped');
assert.equal(aggWarm.observedSampleCount, 4, '4 observed samples tracked accurately');
assert.equal(aggWarm.syntheticSampleCount, 0, 'Zero synthetic samples when >= 3 observed samples exist');
assert.equal(aggWarm.provenance, 'OBSERVED_SECONDARY', '>= 3 observed samples marked as OBSERVED_SECONDARY');
assert.equal(aggWarm.epistemicStatus, 'OBSERVED', '>= 3 observed samples marked as OBSERVED');
assert.equal(aggWarm.dataMode, 'OBSERVED_MARKET', '>= 3 observed samples marked as OBSERVED_MARKET');
assert.ok(aggWarm.observedIqrLowPerSqm !== null && aggWarm.observedIqrHighPerSqm !== null, '>= 3 observed samples populate observed IQR quantiles');
assert.notEqual(aggWarm.askingPricePerSqm, aggWarm.estimatedDealPricePerSqm, 'Asking price and heuristic deal price remain distinct metrics');
assert.equal(aggWarm.evidenceQuality, 'MODERATE_OBSERVATIONS', '4 samples marked as MODERATE_OBSERVATIONS');
assert.ok(Math.abs(aggWarm.hedonicAdjustedPerSqm - 140) / 140 <= 0.031, 'Daily velocity cap (+-3%) enforced');
assert.equal(aggWarm.marketRegime, 'BALANCED', '4 balanced samples classified as BALANCED');

// 10+ samples -> ADEQUATE_OBSERVATIONS & HOT regime
const tenSamples = Array.from({ length: 10 }, (_, idx) => ({
  id: `hot-${idx + 1}`,
  askingTotalMillion: 14000 + (idx % 3) * 150,
  description: '۱۰۰ متر طبقه ۳ با پارکینگ و آسانسور ساخت ۱۴۰۰',
  yearOrAge: 1400,
}));
const aggHot = aggregateNeighborhoodMarketMetrics(1, 'سعادت‌آباد', 140, tenSamples, 140);
assert.equal(aggHot.evidenceQuality, 'ADEQUATE_OBSERVATIONS', '10 samples marked as ADEQUATE_OBSERVATIONS');
assert.equal(aggHot.marketRegime, 'HOT', '10 active samples classified as HOT');
assert.equal(aggHot.askToDealRatio, 0.975, 'HOT regime uses 0.975 askToDealRatio');

// Reachable FROZEN regime & Anchor Clamping transparency
const stagnantSamples = [
  { askingTotalMillion: 16500, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { askingTotalMillion: 17200, description: '۱۰۰ متر طبقه ۳ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { askingTotalMillion: 18000, description: '۱۰۰ متر طبقه ۴ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { askingTotalMillion: 16800, description: '۱۰۰ متر طبقه ۱ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
];
const aggFrozen = aggregateNeighborhoodMarketMetrics(1, 'سعادت‌آباد', 140, stagnantSamples, 140);
assert.equal(aggFrozen.marketRegime, 'FROZEN', 'High-ask stagnant samples reach FROZEN regime');
assert.equal(aggFrozen.askToDealRatio, 0.9, 'FROZEN regime uses 0.90 askToDealRatio');
assert.equal(aggFrozen.isAnchorClamped, true, 'Anchor clamping is flagged when raw average exceeds +-3% daily band');
assert.ok(aggFrozen.unclampedAveragePerSqm > aggFrozen.hedonicAdjustedPerSqm, 'Unclamped average preserved alongside clamped anchor');

// Statistical IQR Outlier vs Predatory Fraud vs Malformed separation
const pureStatOutlierSamples = [
  { askingTotalMillion: 14000, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { askingTotalMillion: 14100, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { askingTotalMillion: 13900, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { askingTotalMillion: 14050, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { askingTotalMillion: 14000, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
  { askingTotalMillion: 19500, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },
];
const aggStatOnly = aggregateNeighborhoodMarketMetrics(1, 'سعادت‌آباد', 140, pureStatOutlierSamples, 140);
assert.equal(aggStatOnly.suspectedFraudCount, 0, 'Statistical outlier alone is never counted as suspected fraud');
assert.equal(aggStatOnly.fraudReviewState, 'STATISTICAL_OUTLIER', 'Pure IQR exclusion sets STATISTICAL_OUTLIER state, not fraud');

const mixedOutlierSamples = [
  ...pureStatOutlierSamples,
  { askingTotalMillion: 4000, description: '۱۰۰ متر طبقه ۲ ساخت ۱۴۰۰ با پارکینگ', yearOrAge: 1400 },  // predatory bait anomaly (40/140 = 0.28x < 0.42x)
  { askingTotalMillion: -500, description: '۱۰ متر نامعتبر', yearOrAge: 1400 },                       // malformed sample
];
const aggOutlier = aggregateNeighborhoodMarketMetrics(1, 'سعادت‌آباد', 140, mixedOutlierSamples, 140);
assert.equal(aggOutlier.observedSampleCount, 8, 'Total raw samples counted in observedSampleCount');
assert.equal(aggOutlier.malformedSampleCount, 1, 'Malformed sample counted separately');
assert.equal(aggOutlier.suspectedFraudCount, 1, 'Predatory bait anomaly counted in suspectedFraudCount');
assert.equal(aggOutlier.fraudReviewState, 'FRAUD_SUSPECTED', 'Predatory anomaly sets FRAUD_SUSPECTED, distinct from FRAUD_CONFIRMED');
assert.ok(aggOutlier.excludedOutlierCount >= 1, 'Statistical IQR outlier counted in excludedOutlierCount');

const spatialGrowth = applySpatialGrowthFallback(
  { id: 1, lat: 35.78, lng: 51.37, buyPerSqm: 150 },
  [
    { id: 2, lat: 35.79, lng: 51.38, buyPerSqm: 155, growthPct: 14.0 },
    { id: 3, lat: 35.77, lng: 51.36, buyPerSqm: 145, growthPct: 12.0 },
  ]
);
assert.ok(spatialGrowth > 11 && spatialGrowth < 15, `Spatial growth fallback interpolated (got ${spatialGrowth})`);

assert.equal(aggCold.coverageState, 'BOOTSTRAPPED_BASELINE', '0 samples maps to BOOTSTRAPPED_BASELINE coverageState');
assert.equal(aggCold.evidenceIndexFormula, '0_OBS=0|1_OBS=35|2_OBS=52|3PLUS_OBS=CLAMP(62+3*N,65,98)_COVERAGE_INDEX_NOT_PROBABILITY', 'Formula metadata explicitly documented on AggregatedMarketMetrics');
assert.equal(aggCold.marketActivityEvidence, 'NO_TRANSACTION_VELOCITY_DATA_DISPERSION_HEURISTIC', 'Market activity evidence explicitly flags absence of transaction velocity');
assert.equal(aggCold.negotiationMultiplierBasis, 'HYPOTHETICAL_SCENARIO_ASSUMPTION_NOT_EMPIRICAL', 'Negotiation multiplier basis explicitly flags hypothetical assumption');
assert.equal(aggOne.coverageState, 'SPARSE_1_TO_2', '1 sample maps to SPARSE_1_TO_2 coverageState');
assert.equal(aggTwo.coverageState, 'SPARSE_1_TO_2', '2 samples maps to SPARSE_1_TO_2 coverageState');
assert.equal(aggWarm.coverageState, 'MODERATE_3_TO_9', '4 samples maps to MODERATE_3_TO_9 coverageState');
assert.equal(aggHot.coverageState, 'SUFFICIENT_10_PLUS', '10 samples maps to SUFFICIENT_10_PLUS coverageState');

// 9. Full 15-case self-verification check
const selfCheck = verifyPricingEngineIntegrity();
assert.equal(selfCheck.passed, true, `Self-verification failed: ${selfCheck.failures.join('; ')}`);

console.log('✅ All Persian NLP & Real Market Price Aggregator v6.4 + WS-G4A-A1 tests passed successfully!');
